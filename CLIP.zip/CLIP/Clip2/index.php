<?php
header("Content-type: application/json;");  
require 'vendor/autoload.php';

use Goutte\Client;
function PhotoPost(){
    $list = [
        'love~1~all~bst',
        'sad~1~all~bst',
        'nature~1~all~bst',
        'art~1~all~bst',
        'design~1~all~bst',
        'sport~1~all~bst',
        'people~1~all~bst',
        'religious~1~all~bst',
        'animals~1~all~bst',
        'architecture~1~all~bst',
        'city~1~all~bst',
        'fashion~1~all~bst',
        'business~1~all~bst',
        'food~1~all~bst',
        'tourism~1~all~bst',
        'technology~1~all~bst',
        'typography~1~all~bst',
        'other~1~all~bst'
    ];
    $rand = rand(0 , count($list)-1);
    $client = new Client();
    $crawler = $client->request('GET', 'https://taw-bio.ir/f/cat/image/'.$list[$rand]);
    
    $results = [];
    
    $crawler->filter('img')->each(function ($node) use (&$results) {

        $src = $node->attr('src');
        $alt = $node->attr('alt');
    
        $results[] = [
            $alt,$src
        ];
    });
    
    
    $rand = rand(0 , count($results)-1);
    
    echo json_encode($results[$rand],448);
    
}


try {
    PhotoPost();
} catch (Exception){
    return;
}