<?php
header("Content-type: application/json;");  
require 'vendor/autoload.php';

use Goutte\Client;
function VideoPost(){
    $list = [
        'love~1~all~bst',
        'sad-cry~1~all~bst',
        'sport~1~all~bst',
        'game~1~all~bst',
        'cartoons~1~all~bst',
        'Joke~1~all~bst',
        'education~1~all~bst',
        'fan~1~all~bst',
        'music+video~1~all~bst',
        'scientific~1~all~bst',
        'technology~1~all~bst',
        'girl~1~all~bst'
    ];
    $rand = rand(0 , count($list)-1);
    $client = new Client();
    $crawler = $client->request('GET', 'https://taw-bio.ir/f/cat/video/'.$list[$rand]);

    $c = [];
    $u = [];
    
    $crawler->filter('.cimg')->each(function ($node) use (&$u) {

        $cimg = $node->attr('href');
    
        $u[] = $cimg;
    });
    
    $crawler->filter('.cimg img')->each(function ($node) use (&$c) {

        $alt = $node->attr('alt');
    
        $c[] = $alt;
    });
    

    
    $rand = rand(0 , count($u)-1);
    
    $urls = $u[$rand];
    $caption = $c[$rand];
    
    
    $crawler = $client->request('GET', $urls);
    
    $results = [];
    
    $crawler->filter('video')->each(function ($node) use (&$results) {

        $cimg = $node->attr('src');
    
        $results[] = $cimg;
    });
    
    echo json_encode([
        'text' => $caption,
        'url' => $results[0]
    ],448);
    
    
}

try {
    VideoPost();
} catch (Exception){
    return;
}